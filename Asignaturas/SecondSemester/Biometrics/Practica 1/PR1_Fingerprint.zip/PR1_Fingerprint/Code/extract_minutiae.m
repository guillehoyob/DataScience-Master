function [valid_x,valid_y]=extract_minutiae(I)


%Create this function based on main.m


end
#!/bin/bash

# INSTRUCTIONS:
# Run this script from the terminal:  ./code_download_onedrive.sh . Files will be downloaded in current directory

wget https://dauam-my.sharepoint.com/:u:/g/personal/alicia_lozano_uam_es/EeymgCUQ2EhPrAvEWf6SQm8By5753NkZHmvmPMslib0A3A?download=1
mv EeymgCUQ2EhPrAvEWf6SQm8By5753NkZHmvmPMslib0A3A?download=1 APPSA_PR2.tar.gz 
tar xvzf APPSA_PR2.tar.gz > /dev/null







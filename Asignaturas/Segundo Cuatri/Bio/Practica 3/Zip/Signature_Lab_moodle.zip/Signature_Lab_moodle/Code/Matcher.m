function Score=Matcher(test,Model)



%YOUR CODE

Score=;

end
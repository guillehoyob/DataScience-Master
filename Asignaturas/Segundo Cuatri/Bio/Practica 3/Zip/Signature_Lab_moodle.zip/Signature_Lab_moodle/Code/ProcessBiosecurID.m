

close all
clear all
clc

%BiosecurIDparameters matrix with: 50 (users) x 16 (signatures/user) x 4 (params)
BiosecurIDparameters=ones(50,16,4);


%YOUR CODE


            
            %You could use this inside your code
            
            %This is how to load the signatures:  
            
            if usuario<10
                BiosecurID=load(['./DB/u100', num2str(user),'s000', num2str(sesion), '_sg000', num2str(sign_genuine), '.mat']);
            else
                BiosecurID=load(['./DB/u10', num2str(user),'s000', num2str(sesion), '_sg000', num2str(sign_genuine), '.mat']);
            end
            
            x=BiosecurID.x;
            y=BiosecurID.y;
            p=BiosecurID.p;
            
            
            
%YOUR CODE         
            
            
            
            

save('BiosecurIDparameters','BiosecurIDparameters');
